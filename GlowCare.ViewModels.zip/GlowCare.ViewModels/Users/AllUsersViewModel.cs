﻿namespace GlowCare.ViewModels.Users;

public class AllUsersViewModel
{
    public Guid Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public ICollection<string> Roles { get; set; } = new List<string>();
}

